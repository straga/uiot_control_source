import {initialState} from "./init.js";

const LOCALSTORAGE_KEY = "upy";


const actions = {
  async fetchSomeData({ state }, records) {
    // const data = await doSomeRPC("/read/", recordId);
    // state.recordId = recordId;
    // state.recordData = data;
      state["state"] = records["data"];
  },

  async addSomeData({ state }, records) {
      state[records["state"]] = records["data"];
  },

  async addTargetData({ state }, records) {

      state[records["state"]][records["target"]].push(records["data"]);

  }



};


export  function makeStore() {
      function saveState(state) {

          const str = JSON.stringify(state);
          window.localStorage.setItem(LOCALSTORAGE_KEY, str);

      }

      function loadState() {

          const localState = window.localStorage.getItem(LOCALSTORAGE_KEY);

          // return localState ? JSON.parse(localState) : initialState;
          return initialState;
      }

      const state = loadState();
      const store = new owl.Store({ state, actions });
      store.on("update", null, () => saveState(store.state));
      return store;
  }