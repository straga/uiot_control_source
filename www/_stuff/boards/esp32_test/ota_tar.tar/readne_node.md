exc bash in node conteiner.
Go to cd /usr/app/projects/utask/www

npm install --global rollup
npm link rollup
npm install --global babel-core
npm link babel-core
npm install --global @babel/core
npm link @babel/core
npm install --global  @babel/plugin-proposal-class-properties
npm link @babel/plugin-proposal-class-properties
npm install --global rollup-plugin-babel
npm link rollup-plugin-babel
npm install --global rollup-plugin-copy
npm link rollup-plugin-copy

rollup -c


npm link gulp
npm link gulp-sourcemaps
npm link gulp-clean-css
npm link gulp-uglify
npm link gulp-concat
npm link gulp-csso
npm link gulp-debug
npm link gulp-gzip
npm link gulp-rename

run gulp owl_mini
run gulp owl_gzip
run gulp owl_esp