from .http_server import WebServer
from .http_client import WebClient
#     self.client = WebClient()

# from .http_response import JsonrRpc
# from .route_rpc import RPCHandler

import sys

import logging
log = logging.getLogger("HTTP")
log.setLevel(logging.DEBUG)

from core.umod.table import uTable

class HTTPServerRunner(uTable):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.server = WebServer()
        self.client = WebClient()

        self.core.mbus.sub_h("HTTP", "http/#", self.env, "http_act")


    async def http_act(self, _id, _key, _pld, _rt):
        log.debug("[ACT]: id: {}, key: {}, pld: {}, rt: {}".format(_id, _key, _pld, _rt))

        if _id == "http/ctr":
            if _key == "start" and not self.server.run:
                await self.http_param()


    async def http_param(self):

        http_obj = await self.sel_one(name="default")
        log.debug("HTTP config from DB")

        if http_obj:
            self.server.addr = http_obj.addr
            self.server.port = http_obj.port
            self.server.path = http_obj.path
            # if http_obj.client:
            #     from .http_client import WebClient
            #     self.client = WebClient()

        _routes = await self.core.umod.call_db("_scan_name", "cfg_http_route")

        m_path = "{}/{}".format(self.core.env["main"].part_name, "mod/http")

        sys.path.append(m_path)
        for route in _routes:
            route_obj = await self.core.umod.call_db("_sel_one", "cfg_http_route", name=route)
            if route_obj:
                try:
                    handler = __import__("{}".format(route_obj["handler"])).Handler
                    self.server.set_route_handler(handler(self.core).route_handler)
                except Exception as e:
                    log.debug("Err: Import: {}".format(e))
                    pass

            log.debug("route: {},".format(route_obj))
        sys.path.remove(m_path)

        self.server.start()



