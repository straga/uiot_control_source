
import json
import logging

log = logging.getLogger("HTTP-RPC-ROUTE")
log.setLevel(logging.INFO)


class Handler:

    def __init__(self, core):

        self.core = core
        self.route_handler = ("/rpc", "POST", self._handler)


    def _error_response(self, e, msg):
        return {
            "code": 0,
            "message": msg,
            "data": {
                "arguments": ["_"],
                "exception_type": "rpc_error",
                "message": "{}".format(e),
                "debug": ""
            }
        }



    # method, mod, *args, ** kwargs
    def query_params(self, params):

        params["args"] = tuple()
        params["kwargs"] = dict()

        if "_args" in params:
            params["args"] = (params["_args"],)

        if "_kwargs" in params:
            params["kwargs"] = params["_kwargs"]

        return params



    async def _handler(self, request):
        upd_size = 0
        if "content-length" in request._headers:
            upd_size = int(request._headers["content-length"])


        log.debug("= : POST DATA (content size): {}".format(upd_size))
        data_post = await request._read_data(upd_size)
        log.debug("> : POST DATA : {}".format(data_post))

        self._queryParams = data_post
        query_params = data_post

        response = {}
        _query = False
        _id = 0

        # JSON DECODE
        try:
            query_decode = query_params.decode()
            _query = json.loads(query_decode)
        except Exception as e:
            response["error"] = self._error_response(e, "RPC-JSON")
            log.error("RPC-JSON: {}".format(e))
            pass

        if _query:

            params = _query["params"]
            _action = params["action"]
            _id = _query["id"]


            # CALL DB
            if _action == "call_db":
                try:

                    parse_query = self.query_params(_query["params"])
                    response["result"] = await self.core.umod.call_db(
                        parse_query["method"],
                        parse_query["model"],
                        *parse_query["args"],
                        **parse_query["kwargs"]
                    )

                except Exception as e:
                    response["error"] = self._error_response(e, "RPC-ENV")
                    log.error("RPC-DB: {}".format(e))
                    pass


            # CALL ENV
            if _action == "call_env":

                _model = params["model"]
                _method = params["method"]

                _options = False
                if "options" in params:
                    pass

                try:
                    method = getattr(self.core.env[_model], _method)

                    if _options:
                        response["result"] = method(_options)
                    else:
                        response["result"] = method()

                except Exception as e:
                    response["error"] = self._error_response(e, "RPC-ENV")
                    log.error("RPC-ENV: {}".format(e))
                    pass

        response["jsonrpc"] = "2.0"
        response["id"] = _id

        await request._response.return_json(response)

        return True





