import logging

log = logging.getLogger("HTTP-FLASH-ROUTE")
log.setLevel(logging.DEBUG)


class Handler:

    def __init__(self, core):

        self.core = core
        self.route_handler = ("/flash", "POST", self._handler)


    async def _handler(self, request):

        result = False
        if "ota" in self.core.env:
            ota = self.core.env["ota"]
            ota_client = ota.ota_client
            result = await ota_client.update(request)

        if result:
            await request._response.return_ok()
            return True
        else:
            return False


        # if written_size == update_size:
        #     await request._response.return_ok()
        #     return True
        # else:
        #     return False

        # CHUNK_SIZE = 512
        # update_size = 0
        # written_size = 0
        # update_type = False
        #
        # if "content-length" in request._headers:
        #     update_size = int(request._headers["content-length"])
        # if "content-type" in request._headers:
        #     update_type = request._headers["content-type"]
        #     if request._headers["content-type"] == "application/octet-stream":
        #         update_type = "stream"
        #     elif request._headers["content-type"] == "application/x-tar":
        #         update_type = "type"
        #
        #
        # log.debug("= : POST DATA (content size): {}".format(update_size))
        # log.debug("= : POST DATA (update type): {}".format(update_type))
        #
        # pieces = int(update_size / CHUNK_SIZE) + (update_size % CHUNK_SIZE > 0)
        # log.debug("= : POST DATA (pieces): {}".format(pieces))
        #
        #
        # last_piece = (pieces - 1)
        #
        # for i in range(0, pieces):
        #
        #     buf = bytes()
        #
        #     try:
        #         if i < last_piece:
        #             buf = await request.reader.readexactly(CHUNK_SIZE)
        #         else:
        #             buf = await request.reader.read(CHUNK_SIZE)
        #     except Exception as e:
        #         log.error("Download: {}".format(e))
        #         break
        #
        #
        #     if buf:
        #         # log.debug("> : POST DATA : {}".format(buf))
        #         # if file:
        #         #     written_size += self.write_file_chunk(buf, file)
        #         # else:
        #         #     written_size += self.write_partition_chunk(buf, i)
        #         written_size += len(buf)
        #
        #         log.info("<- {:.2%}".format(i / last_piece))
        #         if len(buf) < CHUNK_SIZE and i < last_piece:
        #             log.info("{} <- c_sz: {}, w_sz: {}".format(i, len(buf), written_size))
        #             log.debug(buf)
        #
        # log.info("Pieces: {}".format(pieces))
        # log.info("Update size: {}".format(update_size))
        # log.info("Written size = {}".format(written_size))
        #
        # if written_size == update_size:
        #     await request._response.return_ok()
        #     return True
        # else:
        #     return False




