from .ota import OtaClient

import logging
log = logging.getLogger("OTA")
log.setLevel(logging.DEBUG)

from core.umod.table import uTable

class OTARunner(uTable):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.ota_client = OtaClient()







        # http_client = self.env["http"]

        # if hasattr(self.core.env, 'http') and self.core.env["http"].client:
            #self.http_client = OtaClient(self.core.env["http"].client)
        # self.core.mbus.sub_h(uid="HTTP", topic="http/#", env=env, func="http_act")

    # # FTP Actions
    # async def http_act(self, _id, _key, _pld, _rt):
    #     log.debug("[ACT]: id: {}, key: {}, pld: {}, rt: {}".format(_id, _key, _pld, _rt))
    #
    #     if _id == "http/ctr":
    #
    #         if _key == "start":
    #             self.http.set_web_path(self.web_path)
    #             self.http.start()



