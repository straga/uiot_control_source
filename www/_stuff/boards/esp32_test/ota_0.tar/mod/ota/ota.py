# from esp32 import Partition

# # Constructors
# Partition(Partition.FIRST, type=Partition.TYPE_APP)
# Partition(Partition.FIRST, type=Partition.TYPE_DATA)
# Partition(Partition.FIRST, type=Partition.TYPE_DATA, subtype=2, label='nvs')
# Partition(Partition.BOOT) # get boot partition
# Partition(Partition.RUNNING) # get currently running partition
#
# # Methods
# part.info() # returns a 6-tuple of (type, subtype, addr, size, label, encr)
# part.readblocks(block_num, buf)
# part.writeblocks(block_num, buf)
# part.eraseblocks(block_num, size)
# part.set_boot() # sets current as bootable, for next reset
# part.get_next_update() # returns new Partition
#
# app_parts = Partition.find(Partition.TYPE_APP)
# data_parts = Partition.find(Partition.TYPE_DATA)
# nvs_parts = Partition.find(Partition.TYPE_DATA, label='nvs')
#
#
# from esp32 import Partition
# bootpart = Partition(Partition.BOOT)
# runningpart = Partition(Partition.RUNNING)
# fatfs = Partition('fatfs')

try:
    import uasyncio as asyncio
    import uos as os
    import ubinascii as binascii
    import upip_utarfile as utar
    from core.u_os import *

except Exception:
    import asyncio as asyncio
    import os
    import binascii
    import tarfile as utar
    from core.u_os import *


import logging
import hashlib

log = logging.getLogger("OTA")
log.setLevel(logging.DEBUG)

from core.asyn.asyn import launch

# self.core.env["http"]

class OtaClient:

    def __init__(self):
        self.board = "esp32_test"
        self.CHUNK_SIZE = 512
        self.SEC_SIZE = 4096
        self.upd_type = None
        self.upd_size = 0
        self.upd_hash = None

    def set_metadata(self, request):

        if "content-length" in request._headers:
            self.upd_size = int(request._headers["content-length"])
        if "content-type" in request._headers:
            if request._headers["content-type"] == "application/octet-stream":
                self.upd_type = "partition"
            elif request._headers["content-type"] == "application/x-tar":
                self.upd_type = "vfs"
        if "sha256" in request._headers:
            self.upd_hash = request._headers["sha256"]

    async def update(self, request):

        self.set_metadata(request)

        if self.upd_type == "vfs":
            update_vfs = UpdateVFS(next_part="ota_0", cur_part="factory")
            #make file
            update_vfs.file = update_vfs.write_file(update_vfs.TAR_PATH)
            #download file
            await self.download_chunk(request, update_vfs)
            #close file
            update_vfs.file_close()
            # chk_hash = update_vfs.check_file_hash(update_vfs.TAR_PATH, self.upd_hash)
            # # self.remove_file(self.TAR_PATH)
            # log.info("Vfs update corrupt: {}".format(chk_hash))

            if not update_vfs.check_file_hash(update_vfs.TAR_PATH, self.upd_hash):
                update_vfs.remove_file(update_vfs.TAR_PATH)
                log.info("Vfs update corrupt")
                return False
            else:
                log.info("Vfs update OK")
                update_vfs.delete_old_vfs()
                unpack = update_vfs.unpack_tar()
                update_vfs.remove_file(update_vfs.TAR_PATH)
                if not unpack:
                    return False

        if self.upd_type == "partition":
            update_part = UpdatePart(next_part="ota_0", cur_part="factory")


        return True


    async def download_chunk(self, request, updater):

        log.debug("= : POST DATA (content size): {}".format(self.upd_size))
        log.debug("= : POST DATA (update type): {}".format(self.upd_type))

        pieces = int(self.upd_size / self.CHUNK_SIZE) + (self.upd_size % self.CHUNK_SIZE > 0)
        log.debug("= : POST DATA (pieces): {}".format(pieces))

        last_piece = (pieces - 1)
        written_size = 0

        for i in range(0, pieces):

            buf = bytes()

            try:
                if i < last_piece:
                    buf = await request.reader.readexactly(self.CHUNK_SIZE)
                else:
                    buf = await request.reader.read(self.CHUNK_SIZE)
            except Exception as e:
                log.error("Download: {}".format(e))
                break

            if buf:
                if self.upd_type == "vfs":
                    written_size += updater.write_file_chunk(buf, updater.file)

                if self.upd_type == "partition":
                    written_size += updater.write_partition_chunk(buf, i)

                # log.debug("> : POST DATA : {}".format(buf))
                # if file:
                #     written_size += self.write_file_chunk(buf, file)
                # else:
                #     written_size += self.write_partition_chunk(buf, i)
                # written_size += len(buf)

                log.info("<- {:.2%}".format(i / last_piece))
                if len(buf) < self.CHUNK_SIZE and i < last_piece:
                    log.info("{} <- c_sz: {}, w_sz: {}".format(i, len(buf), written_size))
                    log.debug(buf)

        log.info("Pieces: {}".format(pieces))
        log.info("Update size: {}".format(self.upd_size))
        log.info("Written size = {}".format(written_size))









class UpdateVFS:
    def __init__(self, next_part, cur_part, chunk_size=512):
        self.CHUNK_SIZE = chunk_size
        self.next_boot_part = next_part
        self.cur_boot_part = cur_part
        self.TAR_PATH = "/update.tar"
        self.file = False

    def remove_file(self, path):
        try:
            os.remove(path)
        except Exception as e:
            log.error("File not exist: {}".format(e))
            pass

    def write_file(self, path):
        self.remove_file(path)
        f = open(path, "ab")
        return f



    def file_close(self):
        try:
            self.file.close()
        except Exception as e:
            log.error("File not exist: {}".format(e))
            pass


    def write_file_chunk(self, buf, file):
        file.write(buf)
        file.flush()
        return len(buf)

    def check_file_hash(self, path, hash):
        h256 = hashlib.sha256()
        with open(path, 'rb') as f:
            while True:
                buf = f.read(self.CHUNK_SIZE)
                if not buf:
                    break
                h256.update(buf)
        filehash = (binascii.hexlify(h256.digest()).decode())
        log.info('{} hash is "{}", should be "{}"'.format(path, filehash, hash))
        return filehash == hash


    def delete_old_vfs(self):
        deep_delete_folder("/{}".format(self.next_boot_part))
        os.mkdir("/{}".format(self.next_boot_part))

    def unpack_tar(self):
        t = utar.TarFile(self.TAR_PATH)
        updatebasepath = "/{}/".format(self.next_boot_part)
        log.info("Update Base Path: {}".format(updatebasepath))
        for i in t:
            # log.info("info {}".format(i))
            # gc.collect()

            if i.type == utar.DIRTYPE:
                #i_name = i.name[:-1] #upy
                i_name = i.name # pc
                # log.debug("{} -> {}".format(i.name, i_name))
                try:
                    os.mkdir(updatebasepath + i_name)
                except Exception as e:
                    log.debug("mkdir: {}".format(e))
                    return False
            else:
                # log.info("file: {}".format(updatebasepath+i.name))
                with open(updatebasepath+i.name, 'wb') as ef:
                    pf = t.extractfile(i)
                    copy_file_obj(pf, ef)

        return True


class UpdatePart:
    def __init__(self, next_part, cur_part, chunk_size=512, sec_size=4096):
        self.CHUNK_SIZE = chunk_size
        self.SEC_SIZE = sec_size
        self.next_boot_part = next_part
        self.cur_boot_part = cur_part


    def copy_partition(self):
        buf = bytearray(self.CHUNK_SIZE)
        # for i in range(0, self.partitions[self.cur_boot_partition][3]/self.CHUNK_SIZE):
        #     esp.flash_read(self.partitions[self.cur_boot_partition][2]+self.CHUNK_SIZE*i, buf)
        #     self.write_partition_chunk(buf, i)


    def delete_partition(self):
        buf = bytearray(self.CHUNK_SIZE)
        # for i in range(0, self.partitions[self.next_boot_partition][3]/self.CHUNK_SIZE):
        #     self.write_partition_chunk(buf, i)


    def write_partition_chunk(self, buffer, id):
        chunkspersec = (self.SEC_SIZE//self.CHUNK_SIZE)

        # if id%chunkspersec == 0:
        #     esp.flash_erase(self.next_boot_part_base_sec + id//chunkspersec)
        # esp.flash_write(self.partitions[self.next_boot_partition][2]+self.CHUNK_SIZE*id, buffer)

        return len(buffer)

    def check_partition(self, hash, updatesize):
        h = hashlib.sha256()
        parthash = "TEST"
        # buf_sz = int((updatesize / self.CHUNK_SIZE - updatesize // self.CHUNK_SIZE) * self.CHUNK_SIZE)
        # log.debug('First buf_sz {}'.format(buf_sz))
        # if buf_sz == 0:
        #     buf = bytearray(self.CHUNK_SIZE)
        # else:
        #     buf = bytearray(buf_sz)
        #
        # position = self.partitions[self.next_boot_partition][2]
        # pieces = int(updatesize / self.CHUNK_SIZE) + (updatesize % self.CHUNK_SIZE > 0)
        #
        # for i in range(0, pieces):
        #     # log.debug('id {}, P:  {}'.format(i, position))
        #     esp.flash_read(position, buf)
        #     # log.debug('{}'.format(buf))
        #
        #     h.update(buf)
        #     position += len(buf)
        #     buf = bytearray(self.CHUNK_SIZE)
        #
        # parthash = (ubinascii.hexlify(h.digest()).decode())
        #
        # log.info('partition hash is "{}", should be "{}"'.format(parthash, hash))
        return parthash == hash


# class OtaClient:
#
#     def __init__(self, http):
#
#         self.http = http
#         self.board = "esp32_test"
#         self.test()
#
#     async def run(self):
#
#         addr = "http://127.0.0.1"
#         port = "8080"
#
#         url = "{}:{}/rpc".format(addr, port)
#
#         method = "call"
#
#         _fields = {
#             "board": "esp_32"
#         }
#
#         params = {
#                   'action': "call_db",
#                   'model': "cfg_ota_server",
#                   'method': "_sel",
#                   '_kwargs': _fields
#         }
#
#         log.info("Start Update: {}".format(url))
#         resp = await self.http.client.request(url, method, params)
#         log.debug("Resp:{}".format(resp))
#
#         # Data Json
#         if resp:
#
#             data = await resp.read()
#             log.debug("Data:{}".format(data))
#
#         # Data File
#         method = "GET"
#         params = {}
#         url = "{}:{}/boards/esp32_test/ota_bin.bin".format(addr, port)
#
#         resp = await self.http.client.request(url, method, params, rtype="any")
#
#         if resp:
#             while True:
#                 data = await resp.read_data()
#                 if data:
#                     log.debug("Data Stream:{}".format(data))
#
#                 elif data is None:
#                     pass
#                 else:
#                     break
#
#     def test(self):
#         launch(self.run, "")
