from mod.ota.runner import OTARunner

try:
    from ucollections import OrderedDict
except Exception:
    from collections import OrderedDict

def init_db(umod):

    tb_name = "cfg_ota"
    tb_schema = OrderedDict([
        ("name", ""),
        ("ip", ""),
        ("port", ""),
        ("dir", ""),
    ])

    umod.mod_add(tb_name, tb_schema, active="1", up="ap")


    tb_name = "cfg_ota_client"
    tb_schema = OrderedDict([
        ("name", ""),
    ])

    umod.mod_add(tb_name, tb_schema, active="1", up="")


def init_act(core):
    core.env["ota"] = OTARunner(tb_name="cfg_ota", env="ota", core=core)
    return core

