from mod.http.runner import HTTPServerRunner

try:
    from ucollections import OrderedDict
except Exception:
    from collections import OrderedDict

def init_db(umod):

    tb_name = "cfg_http"
    tb_schema = OrderedDict([
        ("name", "default"),
        ("addr", "0.0.0.0"),
        ("port", 8080),
        ("path", "./www"),
        ("client", 0),
    ])
    umod.mod_add(tb_name, tb_schema, active="1", up="ap")

    tb_name = "cfg_http_route"
    tb_schema = OrderedDict([
        ("name", ""),
        ("route", ""),
        ("handler", ""),
    ])
    umod.mod_add(tb_name, tb_schema, active="1", up="ap")

def init_act(core):
    core.env["http"] = HTTPServerRunner(tb_name="cfg_http", env="http", core=core)
    return core

