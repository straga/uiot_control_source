
_name_board = "default"

def push_board(umod):

    umod.data_load("board_cfg",
                   name="default",
                   board="esp32_DOWN_DEV",
                   uid="2132323213",
                   client="dev/esp32_down_led",
                   init=0
                   )


    umod.data_load("board_mod", name="net", active=1, status="")
    umod.data_load("board_mod", name="http", active=1, status="")
    umod.data_load("board_mod", name="ftp", active=1, status="")
    umod.data_load("board_mod", name="telnet", active=1, status="")
    umod.data_load("board_mod", name="ota", active=1, status="")
    # umod.data_load("board_mod", name="mqtt", active=1, status="")
    # umod.data_load("board_mod", name="pin", active=1, status="")
    # umod.data_load("board_mod", name="push", active=1, status="")
    # umod.data_load("board_mod", name="relay", active=1, status="")
    # umod.data_load("board_mod", name="control", active=1, status="")


def push_data(umod):

    # WIFI
    # STA
    umod.data_load("cfg_wifi_sta",
                       name="InetAP_B",
                       ssid="InetAP_B",
                       passwd="bab12345678",
                       active=1
                   )

    umod.data_load("cfg_wifi_sta",
                   name="GZ103_plus",
                   ssid="GZ103_plus",
                   passwd="bunkerwifi",
                   active=1
                   )

    # AP
    umod.data_load("cfg_wifi_ap",
                    name="default",
                    essid="esp32_dev",
                    channel=11,
                    hidden="false",
                    password="dev12345678",
                    authmode=3,

                   )

    #FTP
    umod.data_load("cfg_ftp",
                   name="default",
                   ip="",
                   port=25,
                   dport=26
                   )

    # HTTP
    umod.data_load("cfg_http", name="default", addr="0.0.0.0", port=8080, path="./www")
    umod.data_load("cfg_http_route", name="rpc", route="/rpc", handler="route_rpc")
    umod.data_load("cfg_http_route", name="flash", route="/flash", handler="route_flash")

    # # MQTT
    # umod.data_load("cfg_mqtt",
    #                name="local_2",
    #                type="default",
    #                ip="192.168.100.235"
    #                )
    #
    #
    #
    # # PIN
    # umod.data_load("board_pin", name="led_status", name_pin="21", psy_pin=21)
    # umod.data_load("board_pin", name="relay_1", name_pin="22", psy_pin=22)
    # umod.data_load("board_pin", name="btn_touch", name_pin="19", psy_pin=19)
    # umod.data_load("board_pin", name="btn_touch_b", name_pin="18", psy_pin=18)
    #
    #
    # # PUSH
    #
    # umod.data_load("cfg_push", name="push_touch",
    #                board_pin="btn_touch",
    #                status=["ON", "OFF"],
    #                pin_mode="IN", pin_pull="PULL_DOWN",
    #                type="click", state=None)
    #
    # umod.data_load("cfg_push", name="push_touch_b",
    #                board_pin="btn_touch_b",
    #                status=["ON", "OFF"],
    #                pin_mode="IN", pin_pull="PULL_DOWN",
    #                type="click", state=None)
    #
    #
    # # RELAY
    #
    # umod.data_load("cfg_relay", name="relay_led",
    #                board_pin="led_status",
    #                value_on=1, value_def=0,
    #                pin_mode="OUT", type="led", state=None)
    #
    # umod.data_load("cfg_relay", name="relay_1",
    #                board_pin="relay_1",
    #                value_on=0, value_def=None,
    #                pin_mode="OUT", type="led", state=None)


